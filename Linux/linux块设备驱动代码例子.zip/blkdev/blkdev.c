#include<linux/module.h>
#include<linux/init.h>
#include<linux/kernel.h>
#include<linux/genhd.h>
#include<linux/blkdev.h>

#define BLKDEV_NAME "mydisk"
#define KERNEL_SECTOR_SIZE 512
#define BLKDEV_SIZE (16*1024*1024)
#define READ 0
#define INVALIDATE_DELAY 5*HZ

struct block_dev {
	struct gendisk *gd;
	unsigned char *data;
	spinlock_t lock;
	struct timer_list timer;
	short int users;
	short int media_change;
}*blkdev;

sector_t nsectors = 512;

static int blk_major = 0;
module_param(blk_major, int, 0);
MODULE_PARM_DESC(blk_major, "block device major number");

static unsigned int hardsect_size = 512;
module_param(hardsect_size, int, 0);
MODULE_PARM_DESC(hardsect_size, "block device sector size");


static void blk_do_request(request_queue_t *q)
{
	struct request *req;

	unsigned long offset;
	unsigned long nbytes;

	printk("%s is called.\n", __FUNCTION__);

	while((req = elv_next_request(q)) != NULL){

		offset = req->sector * KERNEL_SECTOR_SIZE;
		nbytes = req->current_nr_sectors * KERNEL_SECTOR_SIZE;

		if((offset + nbytes) > nsectors*hardsect_size){
			printk("<0>""Beyond-end.\n");
			return;
		}

		if(rq_data_dir(req) == READ)
			memcpy(req->buffer, blkdev->data + offset, nbytes);
		else
			memcpy(blkdev->data + offset, req->buffer, nbytes);
			
		end_request(req, 1);
	}
}

static int blk_open(struct inode *inode, struct file *filp)
{
	struct block_dev *dev = inode->i_bdev->bd_disk->private_data;

	printk("%s is called.\n", __FUNCTION__);

	del_timer_sync(&dev->timer);
	filp->private_data = dev;

	spin_lock(&dev->lock);	
	if(!dev->users)
		check_disk_change(inode->i_bdev);
	dev->users++;
	spin_unlock(&dev->lock);
	
	return 0;
}



static int blk_release(struct inode *inode, struct file *file)
{
	struct block_dev *dev = inode->i_bdev->bd_disk->private_data;

	printk("%s is called.\n", __FUNCTION__);
	
	spin_lock(&dev->lock);
	dev->users--;

	if(!dev->users){
		dev->timer.expires = jiffies + INVALIDATE_DELAY;
		add_timer(&dev->timer);
	}

	spin_unlock(&dev->lock);

	return 0;
}

static int blk_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	printk("%s is called.\n", __FUNCTION__);
	return 0;
}

static int check_blk_media_change(struct gendisk *disk)
{
	struct block_dev *dev = blkdev->gd->private_data;

	printk("%s is called.\n", __FUNCTION__);
	
	return dev->media_change;
}	

int blk_revalidate_disk(struct gendisk *gd)
{
	struct block_dev *dev = gd->private_data;

	printk("%s is called.\n", __FUNCTION__);

	if(dev->media_change)
		dev->media_change = 0;

	return 0;
}

void blkdev_invalidate(unsigned long ldev)
{
	struct block_dev *dev = (struct block_dev *)ldev;
	
	printk("%s is called.\n", __FUNCTION__);

	spin_lock(&dev->lock);
	if (dev->users || !dev->data) 
		printk ("timer  check failed\n");
	else
		dev->media_change = 1;
	spin_unlock(&dev->lock);
}

static struct block_device_operations blk_fops = {
	.owner	= THIS_MODULE,
	.open  	= blk_open,
	.release = blk_release,
	.ioctl = blk_ioctl,
	.media_changed = check_blk_media_change,
	.revalidate_disk = blk_revalidate_disk,
};

static int __init simple_blkdev_init(void)
{
	int ret = 0;

	if((blk_major = register_blkdev(blk_major, BLKDEV_NAME)) <= 0){
		printk("<0>""Unable to register block device.\n");
		return -EBUSY;
	}

	blkdev = kzalloc(sizeof(struct block_dev), GFP_KERNEL);
	blkdev->data = vmalloc(BLKDEV_SIZE);
	if(blkdev == NULL || blkdev->data == NULL){
		printk("<0>""kmalloc failed.\n");
		return -ENOMEM;
	}

	blkdev->gd = alloc_disk(1);
	if(!blkdev->gd){
		printk("<0>""alloc_disk failed.\n");
		ret = -ENOMEM;
		goto out;
	}
	
	blkdev->gd->major = blk_major;
	blkdev->gd->first_minor = 0;
	blkdev->gd->fops = &blk_fops,
	blkdev->gd->private_data = blkdev;
	sprintf(blkdev->gd->disk_name, BLKDEV_NAME);
	
	init_timer(&blkdev->timer);
	blkdev->timer.data = (unsigned long)blkdev;
	blkdev->timer.function = blkdev_invalidate;

	spin_lock_init(&blkdev->lock);
	blkdev->gd->queue = blk_init_queue(blk_do_request,&blkdev->lock);
	if(!blkdev->gd->queue){
		printk("<0>""blk_init_queue failed.\n");
		ret = -ENOMEM;
		goto out1;
	}
	
	blk_queue_hardsect_size(blkdev->gd->queue, hardsect_size);
	set_capacity(blkdev->gd, nsectors*(hardsect_size/KERNEL_SECTOR_SIZE));
	
	printk("blk_major is  %d,KERNEL_SECTOR_SIZE is %d.\n",blk_major,KERNEL_SECTOR_SIZE);
	add_disk(blkdev->gd);
		
	return ret;

out1:	
	del_gendisk(blkdev->gd);
out:

	return ret;
}

static void __exit simple_blkdev_exit(void)
{
	blk_cleanup_queue(blkdev->gd->queue);
	del_gendisk(blkdev->gd);
	put_disk(blkdev->gd);
	unregister_blkdev(blk_major, BLKDEV_NAME);
}


module_init(simple_blkdev_init);
module_exit(simple_blkdev_exit);

MODULE_AUTHOR("lvling<lv__ling@126.com>");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("simple block device driver");
