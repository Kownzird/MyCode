#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/platform_device.h>
#include <linux/genhd.h>
#include <linux/blkdev.h>
#include <linux/fs.h>


struct gendisk *gec_disk;
int blk_major = 0;
spinlock_t blk_lock = SPIN_LOCK_UNLOCKED;

char flash[1024*1024];


static int blk_open(struct block_device *bdev, fmode_t mode)
{
	printk(KERN_INFO "blk_open \n");
	return 0;
}


static int blk_release(struct gendisk *gen, fmode_t mode)
{
	printk(KERN_INFO "blk_release \n");
	return 0;
}


static int blk_ioctl(struct block_device *bdev, fmode_t mode, unsigned cmd, unsigned long arg)
{
	printk(KERN_INFO "blk_ioctl \n");
	return -ENOTTY;
}


struct block_device_operations blk_fops = {

	.open = blk_open,
	.release = blk_release,
	.ioctl = blk_ioctl,

};

static  int transfer_data(int sector,int nr_sectors,char *buffer,int dir)
{
//Ӳ�����ݶ�д����
	if(dir)
	{
		memcpy(flash+sector*512,buffer,nr_sectors*512);
	}
	else
	{
		memcpy(buffer,flash+sector*512,nr_sectors*512);
	}
}


void blk_request_fn(struct request_queue *q)
{
	struct request *req;
	printk(KERN_INFO "blk_request_fn \n");

	while( (req = blk_fetch_request(q)) != NULL )
		{
			if( !blk_fs_request(req))
				{
					__blk_end_request_all(req, -EIO);
					continue;
				}
		        transfer_data(blk_rq_pos(req),blk_rq_sectors(req),req->buffer,rq_data_dir(req)); //Ӳ�����ݲ���
				__blk_end_request_all(req, 0);
		}
	
}


static int blk_make_req(struct request_queue *q, struct bio *bio)
{
	int count;
	char *kern_mem;
	char *user_mem;
	struct bio_vec  *bvec;

	count = bio->bi_sector*512 + bio->bi_size;
	if( count > 1024*1024)
		goto err;

	kern_mem = flash + bio->bi_sector*512;

	bio_for_each_segment(bvec, bio, count)
	{
		user_mem = kmap(bvec->bv_page) + bvec->bv_offset;

		switch(bio_data_dir(bio))
		{
			 case READA:
			 case READ:
			 	memcpy(user_mem,kern_mem,bvec->bv_len);
				break;
			 case WRITE:
				memcpy(kern_mem,user_mem,bvec->bv_len);
				break;
			 default:
			 	kunmap(bvec->bv_page);
				bio_endio(bio, -EIO);
				goto err2;
		}
			kunmap(bvec->bv_page);
			kern_mem += bvec->bv_len;
	}
			bio_endio(bio,0);
			return 0;

err:
	printk(KERN_ERR "size ERR! \n");
	return -EIO;
err2:
	printk(KERN_ERR "param ERR! \n");
	return -EIO;
}

static int __init blk_drv_init(void)
{
	printk(KERN_INFO "blk_drv_init\n");

	blk_major = register_blkdev(0,"gec_blk");
	if(blk_major < 0)
		{
		 printk(KERN_ERR "register_blkdev failed! \n");	
		}
	
	gec_disk = alloc_disk(1);  //����gendisk�豸�ṹ��ռ�
	gec_disk->major = blk_major;
	gec_disk->first_minor = 0;
	gec_disk->minors = 1;
	sprintf(gec_disk->disk_name,"gec_blk");
	gec_disk->fops = &blk_fops;

	//��еӲ��ͨ�÷���
	//gec_disk->queue = blk_init_queue(blk_request_fn, &blk_lock);

	//����Ӳ��ͨ�÷���(ramdisk)
	gec_disk->queue = blk_alloc_queue(GFP_KERNEL);
	blk_queue_make_request(gec_disk->queue, blk_make_req);
	
	gec_disk->private_data = gec_disk;
	blk_queue_logical_block_size(gec_disk->queue, 512);
	set_capacity(gec_disk, 2048);

	add_disk(gec_disk);
	
}

static void __exit blk_drv_exit(void)
{
	unregister_blkdev(blk_major,"gec_blk");
	blk_cleanup_queue(gec_disk->queue);
	del_gendisk(gec_disk);

}


module_init(blk_drv_init);
module_exit(blk_drv_exit);

MODULE_AUTHOR("GEC");
MODULE_DESCRIPTION("blk device module.");
MODULE_LICENSE("GPL");

